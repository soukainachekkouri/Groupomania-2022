import "../styles/components/Textholder.css";
//import logo from "../assets/logo.png";
//import avatar from "../assets/avatar.png";

function Textholder() {
  return (
    <div className="gpm-textholder">
      <div className="title"> </div>{" "}
    </div>
  );
}

export default Textholder;
