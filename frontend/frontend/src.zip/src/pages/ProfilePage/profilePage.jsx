import "../ProfilePage/profilePage.css";
import React, { useState } from "react";

const ProfilePage = (props) => {
  return (
    <div>
      <div>
        <h1>Mon profile</h1>
      </div>
    </div>
  );
};

export default ProfilePage;
